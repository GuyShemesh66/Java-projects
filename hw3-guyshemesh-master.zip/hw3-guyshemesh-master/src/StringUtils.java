
public class StringUtils {

    public static String findSortedSequence(String str) {
        // TODO
        int start=0;
        int stringLong=0;
        int end=0;
        int maxStart=0;
        int maxEnd=0;
        int maxLong=0;
        String newStr ="";
        String[] maxString=str.split(" ");
        
            for(int i=0;i< maxString.length-1;i++)
            {
                if(maxString[i].compareTo(maxString[i+1])<=0)
                {
                    stringLong++;
                    end=i+1;
                    if(maxLong<stringLong&&i==maxString.length-2)
                    {
                        maxLong=stringLong;
                        stringLong=1;
                        maxEnd=end;
                        maxStart=start;
                         start=i+1;
                         end=i+1;
                    }
                }
                else{
                    if(maxLong<=stringLong)
                    {
                        maxLong=stringLong;
                        stringLong=1;
                        maxEnd=end;
                        maxStart=start;
                         start=i+1;
                         end=i+1;
                     }
                    else {
                        stringLong=1;
                        start=i+1;
                         end=i+1;
                    }
                }
            }
            if(maxString.length!=0) {
                for (int i=maxStart;i<=maxEnd;i++)
                {
                    newStr=newStr+maxString[i];
                    if(i!=maxEnd) {
                        newStr=newStr+" ";
                    }
                 }
            }
                if (maxLong==1) 
                {
                    return maxString[maxString.length-1];
                }
                else {
                  return newStr; 
                }

    }

    
    public static boolean isEditDistanceOne(String a, String b){
        // TODO
        int changeCount=0;
        if (Math.abs(a.length()-b.length())>1) {
            return false;
        }
        else if(a.length()==b.length()) {
           for (int i=0;i<a.length();i++) {
            if(a.charAt(i)!=b.charAt(i)) {
                changeCount=changeCount+1;
            }
           }
        }
        else{
            if (Math.abs(a.length()-b.length())==1)
              {
                if(a.length()<b.length()) {
                    for(int i=0;i<a.length();i++) {
                        while((changeCount!=2)&&(a.charAt(i)!=b.charAt(i+changeCount))){
                            changeCount++;
                        }        
                    }
               }
            }
                else {
                    for(int i=0;i<b.length();i++) {
                         while((changeCount!=2)&&(b.charAt(i)!=a.charAt(i+changeCount))) {
                        changeCount++;
                         }        
                    }    
               }
            }
        
             if(changeCount>1){
                return false;
            }    
               return true; 
    }
}
