package il.ac.tau.cs.sw1.ex8.tfIdf;

public class FileIndexException extends Exception{


	private static final long serialVersionUID = 1L;

	public FileIndexException(String message){
		super(message);
	}
}
