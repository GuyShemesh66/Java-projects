package il.ac.tau.cs.sw1.riddle.b;

/**
 * Complete the code of A's methods without changing B and C.
 */
public class A {

	private B b;

	public A(B b) {
		this.b = b;
	}

	public static void printA(B b) {
		/* complete */
		String s="";
		B b2=new B(b,s);
	    
	}


	public void printA2() {
		/* complete */ 
		B.foo(b);
	}
 
	public static void printA3(A a) {
		/* complete */
		B b2=a.b;
		b2.methodB(b2);
	}
	
}
